const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const logger = require("./config/logger.config.js");
const requestLogger = require("./middlewares/requestLogger.middleware.js");
const authRoutes = require("./routes/auth.routes.js");
const projectRoutes = require("./routes/project.routes.js");
const taskRoutes = require("./routes/task.routes.js")

const { verifyToken } = require("./middlewares/auth.middleware.js");

const swaggerUi = require("swagger-ui-express");
const swaggerSpec = require("./config/swagger.config.js"); // import swagger-jsdoc config

const basicAuth = require("express-basic-auth");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(requestLogger);

app.use(
  "/docs",
  basicAuth({
    users: { 
      [process.env.SWAGGER_USER || "admin"]: process.env.SWAGGER_PASS || "supersecret123"
    },
    challenge: true,
  }),
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpec)
);

app.use("/api/auth", authRoutes);

app.use("/api/projects", verifyToken, projectRoutes);
app.use("/api/tasks", taskRoutes);

app.get("/", (req, res) => {
  logger.info({
    apiId: "ROOT",
    action: "Base route accessed",
    requestId: req.requestId,
    sessionId: req.sessionId,
    message: "Welcome route hit",
  });

  res.json({
    message: "Welcome to Ask Innovation Backend",
    status: "Running",
  });
});

app.use((err, req, res, next) => {
  logger.error({
    apiId: "GLOBAL_ERROR",
    action: "Unhandled exception",
    requestId: req.requestId,
    sessionId: req.sessionId,
    error: err.message,
    stack: process.env.NODE_ENV === "development" ? err.stack : undefined,
  });

  res.status(500).json({
    success: false,
    message: "Internal Server Error",
    error: process.env.NODE_ENV === "development" ? err.message : undefined,
  });
});

app.listen(PORT, () => {
  logger.info({
    apiId: "SERVER_START",
    action: "Server startup",
    message: `Server is running on port ${PORT}`,
  });
});

module.exports = app;
