const jwt = require("jsonwebtoken");
const { errorResponse } = require("../utils/response.util.js");

const JWT_SECRET = process.env.JWT_SECRET;

module.exports.verifyToken = (req, res, next) => {
  const header = req.headers.authorization;

  if (!header)
    return res
      .status(401)
      .json(errorResponse("Token required"));

  const token = header.split(" ")[1];

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res
      .status(401)
      .json(errorResponse("Invalid token"));
  }
};
