const express = require("express");
const {
  createTaskController,
  getTasksController,
  getMyTasksController,
  deleteTaskController
} = require("../controllers/task.controller.js");
const { verifyToken } = require("../middlewares/auth.middleware");
const { allowRoles } = require("../middlewares/role.middleware");
const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Tasks
 *   description: Task management APIs
 */

/**
 * @swagger
 * /api/tasks:
 *   post:
 *     summary: Create a task
 *     tags: [Tasks]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - title
 *               - project_id
 *               - assigned_to
 *             properties:
 *               title:
 *                 type: string
 *               description:
 *                 type: string
 *               project_id:
 *                 type: integer
 *               assigned_to:
 *                 type: integer
 *               priority:
 *                 type: string
 *                 example: high
 *               status:
 *                 type: string
 *                 example: pending
 *     responses:
 *       201:
 *         description: Task created
 */

// ADD TASK
router.post("/", createTaskController);

/**
 * @swagger
 * /api/tasks:
 *   get:
 *     summary: Get all tasks
 *     tags: [Tasks]
 *     responses:
 *       200:
 *         description: List of tasks
 */

// GET TASKS
router.get("/", getTasksController);


/**
 * @swagger
 * /api/tasks/my-tasks:
 *   get:
 *     summary: Get tasks assigned to logged-in user
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of tasks assigned to the current user
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               data:
 *                 - id: 1
 *                   title: Fix login bug
 *                   description: JWT token issue
 *                   project_id: 2
 *                   project_name: CRM System
 *                   assigned_to: 5
 *                   assigned_user: Moin Khan
 *                   priority: high
 *                   status: pending
 *                   created_at: 2026-02-21T10:00:00.000Z
 *       401:
 *         description: Unauthorized (Token missing or invalid)
 *       500:
 *         description: Internal server error
 */


/**
 * @swagger
 * /api/tasks/{id}:
 *   delete:
 *     summary: Delete a task by ID
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Task ID to delete
 *     responses:
 *       200:
 *         description: Task deleted successfully
 *       403:
 *         description: Forbidden (Not allowed to delete this task)
 *       404:
 *         description: Task not found
 *       401:
 *         description: Unauthorized (Token missing or invalid)
 *       500:
 *         description: Internal server error
 */
router.delete("/:id", verifyToken, deleteTaskController);

/**
 * @swagger
 * /api/tasks/my-tasks:
 *   get:
 *     summary: Get tasks assigned to the current user
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of tasks assigned to the current user
 *         content:
 *           application/json:
 *             example:
 *               success: true
 *               data:
 *                 - id: 1
 *                   title: Fix login bug
 *                   description: JWT token issue
 *                   project_id: 2
 *                   project_name: CRM System
 *                   assigned_to: 5
 *                   assigned_user: Moin Khan
 *                   priority: high
 *                   status: pending
 *                   created_at: 2026-02-21T10:00:00.000Z
 *       401:
 *         description: Unauthorized (Token missing or invalid)
 *       403:
 *         description: Forbidden (Role not allowed)
 *       500:
 *         description: Internal server error
 */
router.get(
  "/my-tasks",
  verifyToken,
  allowRoles("developer", "admin"),
  getMyTasksController
);

module.exports = router;