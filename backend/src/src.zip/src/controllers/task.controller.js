const taskService = require("../services/task.service.js");
const logger = require("../config/logger.config.js");

module.exports.createTaskController = async (req, res) => {
  const apiId = "CREATE_TASK";

  try {
    const taskId = await taskService.addTask(req.body);

    logger.info({
      timestamp: new Date().toISOString(),
      level: "info",
      service: "task-service",
      env: process.env.NODE_ENV,
      apiId,
      action: "create task",
      requestId: req.requestId,
      sessionId: req.sessionId || null,
      userId: req.userId || null,
    });

    return res.status(201).json({
      success: true,
      message: "Task created successfully",
      taskId,
    });

  } catch (error) {

    logger.error({
      timestamp: new Date().toISOString(),
      level: "error",
      service: "task-service",
      env: process.env.NODE_ENV,
      apiId,
      action: "create task failed",
      requestId: req.requestId,
      sessionId: req.sessionId || null,
      userId: req.userId || null,
      error: error.message,
    });

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};


module.exports.getTasksController = async (req, res) => {
  const apiId = "GET_TASKS";

  try {
    const tasks = await taskService.fetchTasks();

    logger.info({
      timestamp: new Date().toISOString(),
      level: "info",
      service: "task-service",
      env: process.env.NODE_ENV,
      apiId,
      action: "get tasks",
      requestId: req.requestId,
    });

    return res.status(200).json({
      success: true,
      data: tasks,
    });

  } catch (error) {

    logger.error({
      timestamp: new Date().toISOString(),
      level: "error",
      service: "task-service",
      env: process.env.NODE_ENV,
      apiId,
      action: "get tasks failed",
      requestId: req.requestId,
      error: error.message,
    });

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};



module.exports.getMyTasksController = async (req, res) => {
  const apiId = "GET_MY_TASKS";

  try {
    const userId = req.user?.id; 
    const tasks = await taskService.fetchTasksByUser(userId);

    logger.info({
      apiId,
      action: "get tasks by user",
      requestId: req.requestId,
      sessionId: req.sessionId,
      userId,
      env: process.env.NODE_ENV,
      service: "ask-innovation-backend"
    });

    return res.status(200).json({
      success: true,
      data: tasks
    });

  } catch (error) {

    logger.error({
      apiId,
      action: "get tasks by user failed",
      requestId: req.requestId,
      sessionId: req.sessionId,
      userId: req.user?.id,
      error: error.message,
      env: process.env.NODE_ENV,
      service: "ask-innovation-backend"
    });

    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

module.exports.deleteTaskController = async (req, res) => {
  const apiId = "DELETE_TASK";

  try {
    const taskId = req.params.id;

    await taskService.deleteTask(taskId, req.user);

    logger.info({
      timestamp: new Date().toISOString(),
      level: "info",
      service: "task-service",
      env: process.env.NODE_ENV,
      apiId,
      action: "delete task",
      requestId: req.requestId,
      sessionId: req.sessionId || null,
      userId: req.user?.id || null,
    });

    return res.status(200).json({
      success: true,
      message: "Task deleted successfully"
    });

  } catch (error) {

    logger.error({
      timestamp: new Date().toISOString(),
      level: "error",
      service: "task-service",
      env: process.env.NODE_ENV,
      apiId,
      action: "delete task failed",
      requestId: req.requestId,
      sessionId: req.sessionId || null,
      userId: req.user?.id || null,
      error: error.message,
    });

    if (error.message === "TASK_NOT_FOUND") {
      return res.status(404).json({
        success: false,
        message: "Task not found"
      });
    }

    if (error.message === "FORBIDDEN") {
      return res.status(403).json({
        success: false,
        message: "You are not allowed to delete this task"
      });
    }

    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};