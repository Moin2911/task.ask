
const logger = require("../config/logger.config.js");
const {
  successResponse,
  errorResponse
} = require("../utils/response.util.js");

const {
  createProjectService,
  getProjectsService
} = require("../services/project.service.js");

const SERVICE_NAME = "ask-innovation-backend";
const ENV = process.env.NODE_ENV || "dev";


module.exports.createProjectController = async (req, res) => {
  try {

    const data = await createProjectService(req.body, req.user);

    logger.info({
      apiId: "PROJECT_CREATE",
      action: "Create project",
      requestId: req.requestId,
      sessionId: req.sessionId,
      userId: req.user?.id,
      message: "Project created successfully",
      env: ENV,
      service: SERVICE_NAME
    });

    return res
      .status(201)
      .json(successResponse(data, "Project created successfully"));

  } catch (error) {

    logger.error({
      apiId: "PROJECT_CREATE",
      action: "Create project failed",
      requestId: req.requestId,
      sessionId: req.sessionId,
      userId: req.user?.id,
      error: error.message,
      message: "Project creation failed",
      env: ENV,
      service: SERVICE_NAME
    });

    return res
      .status(error.status || 500)
      .json(errorResponse(error.message, "PROJECT_CREATE_FAILED"));
  }
};


module.exports.getProjectsController = async (req, res) => {
  try {
console.log(req.user)
    const data = await getProjectsService(req.user);

    logger.info({
      apiId: "PROJECT_GET",
      action: "Get projects",
      requestId: req.requestId,
      sessionId: req.sessionId,
      userId: req.user?.id,
      role: req.user?.role,
      message: "Projects fetched successfully",
      env: ENV,
      service: SERVICE_NAME
    });

    return res
      .status(200)
      .json(successResponse(data, "Projects fetched"));

  } catch (error) {

    logger.error({
      apiId: "PROJECT_GET",
      action: "Get projects failed",
      requestId: req.requestId,
      sessionId: req.sessionId,
      userId: req.user?.id,
      error: error.message,
      message: "Failed to fetch projects",
      env: ENV,
      service: SERVICE_NAME
    });

    return res
      .status(500)
      .json(errorResponse(error.message, "PROJECT_FETCH_FAILED"));
  }
};









module.exports.helloController = async () => {
  try {
    const data = getHelloService();

    logger.info("Hello API called", { data });

    return {
      status: 200,
      body: successResponse(data)
    };
  } catch (error) {
    logger.error("Hello API error", {
      message: error.message,
      stack: error.stack
    });

    return {
      status: 500,
      body: errorResponse()
    };
  }
};
