const pool = require("../config/db.config.js");

module.exports.createUser = async (user) => {
  const {
    name,
    email,
    password,
    role,
    phone,
    project_id,
    priority
  } = user;

  const [result] = await pool.execute(
    `INSERT INTO users
     (name, email, password, role, phone, project_id, priority)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [name, email, password, role, phone, project_id, priority]
  );

  return {
    id: result.insertId,
    name,
    email,
    role,
    phone,
    project_id,
    priority
  };
};

module.exports.findUserByEmail = async (email) => {
  const [rows] = await pool.execute(
    "SELECT * FROM users WHERE email = ? LIMIT 1",
    [email]
  );

  return rows[0] || null;
};

module.exports.deleteUserById = async (id) => {
  const [result] = await pool.execute(
    "DELETE FROM users WHERE id = ?",
    [id]
  );

  return result.affectedRows;
};


// GET ALL EMPLOYEES
module.exports.getAllEmployees = async () => {
  const [rows] = await pool.execute(
    `SELECT 
        id,
        name,
        email,
        role,
        phone,
        project_id,
        priority,
        created_at
     FROM users`
  );

  return rows;
};


// GET EMPLOYEE BY ID
module.exports.getEmployeeById = async (id) => {
  const [rows] = await pool.execute(
    `SELECT 
        id,
        name,
        email,
        role,
        phone,
        project_id,
        priority,
        created_at
     FROM users
     WHERE id = ?`,
    [id]
  );

  return rows[0] || null;
};