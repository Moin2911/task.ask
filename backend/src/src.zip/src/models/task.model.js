const db = require("../config/db.config.js");

// CREATE TASK
module.exports.createTask = async (data) => {
  const sql = `
    INSERT INTO tasks
    (title, description, project_id, assigned_to, priority, status)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  const [result] = await db.execute(sql, [
    data.title,
    data.description,
    data.project_id,
    data.assigned_to,
    data.priority || "medium",
    data.status || "pending",
  ]);

  return result.insertId;
};

// GET ALL TASKS
module.exports.getTasks = async () => {
  const sql = `
    SELECT 
      t.*,
      p.name AS project_name,
      u.name AS assigned_user
    FROM tasks t
    JOIN projects p ON t.project_id = p.id
    JOIN users u ON t.assigned_to = u.id
    ORDER BY t.created_at DESC
  `;

  const [rows] = await db.execute(sql);
  return rows;
};



// GET TASKS BY USER ID
module.exports.getTasksByUser = async (userId) => {
  const sql = `
    SELECT 
      t.*,
      p.name AS project_name,
      u.name AS assigned_user
    FROM tasks t
    JOIN projects p ON t.project_id = p.id
    JOIN users u ON t.assigned_to = u.id
    WHERE t.assigned_to = ?
    ORDER BY t.created_at DESC
  `;

  const [rows] = await db.execute(sql, [userId]);
  return rows;
};


module.exports.getTaskById = async (taskId) => {
  const sql = "SELECT * FROM tasks WHERE id = ?";
  const [rows] = await db.execute(sql, [taskId]);
  return rows[0];
};

module.exports.deleteTaskById = async (taskId) => {
  const sql = "DELETE FROM tasks WHERE id = ?";
  const [result] = await db.execute(sql, [taskId]);
  return result.affectedRows;
};