const pool = require("../config/db.config.js");

// 👑 ADMIN → all projects
module.exports.getAllProjects = async () => {
  const [rows] = await pool.execute(
    "SELECT * FROM projects ORDER BY id DESC"
  );
  return rows;
};

// 👨‍💻 USER → projects where user has tasks
module.exports.getProjectsByUser = async (userId) => {
  const [rows] = await pool.execute(
    `
    SELECT DISTINCT p.*
    FROM projects p
    JOIN tasks t ON p.id = t.project_id
    WHERE t.assigned_to = ?
    ORDER BY p.id DESC
    `,
    [userId]
  );
  return rows;
};


module.exports.createProject = async (data) => {
  const [result] = await pool.execute(
    `
    INSERT INTO projects (name, description, status)
    VALUES (?, ?, ?)
    `,
    [data.name, data.description, data.status]
  );

  return {
    id: result.insertId,
    ...data
  };
};