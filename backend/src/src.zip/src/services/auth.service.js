const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const {
  createUser,
  findUserByEmail,
  deleteUserById,
    getAllEmployees,
  getEmployeeById
} = require("../models/user.model.js");


const JWT_SECRET = process.env.JWT_SECRET;

const ALLOWED_ROLES = ["admin", "developer"];

module.exports.registerService = async (data) => {
  try {
    if (!ALLOWED_ROLES.includes(data.role)) {
      throw {
        status: 400,
        message: "This role is not allowed"
      };
    }

    const hashedPassword = await bcrypt.hash(data.password, 10);

    return await createUser({
      ...data,
      password: hashedPassword
    });
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") {
      throw {
        status: 409,
        message: "User already exists"
      };
    }
    throw err;
  }
};

module.exports.loginService = async ({ email, password }) => {
  const user = await findUserByEmail(email);
  if (!user) throw new Error("Invalid credentials");

  const match = await bcrypt.compare(password, user.password);
  if (!match) throw new Error("Invalid credentials");

  const token = jwt.sign(
    {
      id: user.id,
      role: user.role,
       project_id: user.project_id  
    },
    JWT_SECRET,
    { expiresIn: "1h" }
  );
  console.log(user.id,user.role,user.project_id)
  return {
    id: user.id,
    email: user.email,
    role: user.role,
    token
  };
};


module.exports.deleteEmployeeService = async (id) => {
  const deleted = await deleteUserById(id);

  if (!deleted) {
    throw {
      status: 404,
      message: "Employee not found"
    };
  }

  return { message: "Employee deleted successfully" };
};


exports.getEmployeesService = async () => {
  return await getAllEmployees();
};

exports.getEmployeeByIdService = async (id) => {
  return await getEmployeeById(id);
};