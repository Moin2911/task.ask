const taskModel = require("../models/task.model.js");

async function addTask(data) {
  return await taskModel.createTask(data);
}

async function fetchTasks() {
  return await taskModel.getTasks();
}

async function fetchTasksByUser(userId) {
  return await taskModel.getTasksByUser(userId);
}


async function deleteTask(taskId, user) {

  const task = await taskModel.getTaskById(taskId);

  if (!task) {
    throw new Error("TASK_NOT_FOUND");
  }

  if (user.role === "admin") {
    return await taskModel.deleteTaskById(taskId);
  }

  if (task.assigned_to !== user.id) {
    throw new Error("FORBIDDEN");
  }

  return await taskModel.deleteTaskById(taskId);
}


module.exports = {
  addTask,
  fetchTasks,
  fetchTasksByUser,
  deleteTask,
};