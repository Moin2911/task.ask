const {
  getAllProjects,
  getProjectsByUser,createProject
} = require("../models/project.model.js");

module.exports.getProjectsService = async (user) => {

  if (user.role === "admin") {
    return await getAllProjects();
  }

  return await getProjectsByUser(user.id);
};


module.exports.createProjectService = async (data, user) => {

  if (user.role !== "admin") {
    throw {
      status: 403,
      message: "Only admin can create projects"
    };
  }

  if (!data.name) {
    throw {
      status: 400,
      message: "Project name is required"
    };
  }

  const project = await createProject({
    name: data.name,
    description: data.description || "",
    status: data.status || "active"
  });

  return project;
};